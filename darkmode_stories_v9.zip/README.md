# DARKMODE STORIES — Version 9

Version 9 converts the prototype into a modular GitHub-ready project.

## Preview locally

Because the sticker library uses `fetch()`, use a small local web server rather than double-clicking `index.html`:

```bash
python -m http.server 8000
```

Then visit:

```text
http://localhost:8000
```

GitHub Pages will serve everything correctly over HTTPS.

## Native device emojis

The emoji button opens a panel containing a real text input and focuses it. This asks the device to display its normal keyboard. On the Fire tablet, use the keyboard's smiley/emoji key.

Browsers do not provide a reliable universal API that directly forces the operating system emoji panel to open. A built-in quick-emoji fallback remains available.

## Dynamic sticker folder

Add original or licensed files to:

```text
assets/stickers/
```

Supported formats:

- PNG
- JPG/JPEG
- WebP
- GIF
- SVG

When pushed to GitHub, `.github/workflows/refresh-stickers.yml` runs automatically and regenerates:

```text
assets/stickers/manifest.json
```

The application loads that manifest every time the page opens.

## Project structure

- `index.html` — document structure
- `css/main.css` — complete design and animation system
- `js/app.js` — interface behavior
- `assets/stickers/` — sticker artwork and generated manifest
- `scripts/` — development utilities
- `.github/workflows/` — GitHub automation
- `docs/DARKMODE-BRAND-STANDARDS.md` — initial brand system

## Rights

Only add artwork you own, created, commissioned, or properly licensed.
